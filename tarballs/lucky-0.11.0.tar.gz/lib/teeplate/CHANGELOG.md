
# Changelog

## :)

### Format

Based on [Keep a Changelog].

### Versioning Policy

[Semantic Versioning Caret]

## Versions

### [Edge (HEAD)][edge]

### [0.6.1]

#### Fixed

* Fixes VERSION

### [0.6.0]

#### Changed

* Changes Crystal to 0.25.0.
* Sorts entries before rendering.

### [0.5.0]

#### Changed

* Changes Crystal to 0.24.2.

[Keep a Changelog]: http://keepachangelog.com/en/1.0.0/
[Semantic Versioning Caret]: https://github.com/malform/semver-caret
[edge]: https://github.com/mosop/have_files/compare/v0.6.0...HEAD
[0.5.0]: https://github.com/mosop/teeplate/compare/v0.4.5...v0.5.0
[0.6.0]: https://github.com/mosop/teeplate/compare/v0.4.5...v0.6.0
[0.6.1]: https://github.com/mosop/teeplate/compare/v0.6.0...v0.6.1
